



















RedBloons= 1
BlueBloons= 2
GreenBloons= 3
YellowBloons= 4
PinkBloons= 5
BlackBloons = 11
PurpleBloons = 11
LeadBloons = 23
ZebraBloons =23
RainbowBloons = 47
CeramicBloons = 95
MOAB = 381
bfb= 1525
zomg= 6101
ddt= 381
bad= 13346

qRedBloons= int (input("Quantos Red Bloons? vc estourou?:"))
qBlueBloons= int (input("Quantos Blue Bloons? vc estourou?:"))
qGreenBloons= int (input("Quantos Green Bloons? vc estourou?:"))
qYellowBloons= int (input("Quantos Yellow Bloons? vc estourou?:"))
qPinkBloons= int (input ("Quantos Pink Bloons? vc estourou?:"))
qBlackBloons= int (input("Quantos Black Bloons? vc estourou ?:"))
qPurpleBloons= int (input("Quantos Purple Bloons? vc estourou?:"))
qLeadBloons= int (input("Quantos Lead Bloons? vc estourou ?:"))
qZebraBloons= int (input("Quantos Zebra Bloons? vc estourou?:"))
qRainbowBloons= int (input("Quantos Rainbow Bloons? vc estourou?:"))
qCeramicBloons= int (input("Quantos Ceramic Bloons? vc estourou?:"))
qMOAB= int (input("Quantos MOAB? vc estourou?:"))
qbfb= int (input("Quantos bfb? vc estourou?:"))
qzomg= int (input("Quantos zomg? vc estourou?:"))
qddt= int (input("Quantos ddt? vc estourou?:"))
qbad= int (input("Quantos bad? vc estourou?:"))

print ("Voce ganhou ", (qRedBloons*RedBloons)+(qBlueBloons*BlueBloons)+(qGreenBloons*GreenBloons)+(qYellowBloons*YellowBloons)+(qPinkBloons*PinkBloons)+(qBlackBloons*BlackBloons)+(qPurpleBloons*PurpleBloons)+(qLeadBloons*LeadBloons)+(qZebraBloons*ZebraBloons)+(qRainbowBloons*RainbowBloons)+(qCeramicBloons*CeramicBloons)+(qMOAB*MOAB)+(qbfb*bfb)+(qzomg*zomg)+(qddt*ddt)+(qbad*bad) , "de dinheiro kkkkkkk!")