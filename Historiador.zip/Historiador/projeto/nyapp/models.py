from django.db import models

# Create your models here.

class Pessoa(models.Model):
    nome = models.CharField(max_length=50)
    email = models.EmailField(default='')
    hid = models.CharField(max_length=255, blank=True, null=True)
    def __str__(self):
        return f'{self.nome} {self.email} {self.hid}'
    
class Historia(models.Model):
    titulo = models.TextField()
    conteudo = models.TextField()
    sinopse = models.TextField(blank=True, null=True)
    data = models.DateField(auto_now_add=True)  
    hnome = models.CharField(max_length=50, default="​")
    def __str__(self):
        return f'{self.titulo} {self.conteudo} {self.sinopse} {self.data} {self.hnome}'