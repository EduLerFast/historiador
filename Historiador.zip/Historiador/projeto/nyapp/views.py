from django.shortcuts import render, redirect ,get_object_or_404
from nyapp.models import Pessoa , Historia
from django.urls import reverse
# Create your views here.

def home(request):
    pessoas = Pessoa.objects.all()
    return render(request, "cadastro.html", {'pessoas': pessoas})
    

def cadastro(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        hid = request.POST.get('hid', None)
        
        nova_pessoa = Pessoa(nome=nome, email=email, hid=hid)
        nova_pessoa.save()
        
        # Define a sessão para o novo usuário, logando-o automaticamente
        request.session['pessoa_id'] = nova_pessoa.id
        request.session['pessoa_nome'] = nova_pessoa.nome
        request.session['pessoa_email'] = nova_pessoa.email

        # Redireciona para o lobby
        return redirect(reverse('lobby'))
    return render(request, 'cadastro.html')

def login(request):
    if request.method == 'POST':
        nome = request.POST.get('nome', '').strip()
        email = request.POST.get('email', '').strip()
        if not nome or not email:
            return render(request, 'login.html', {'error': 'Preencha nome e email', 'nome': nome, 'email': email})

        # tenta encontrar pessoa; se não existir, cria (opcional)
        pessoa = Pessoa.objects.filter(nome=nome, email=email).first()
        if not pessoa:
            return redirect(login)

        # define sessão simples para usuário autenticado
        #request.session['pessoa_id'] = pessoa.id
        #request.session['pessoa_nome'] = pessoa.nome
        #request.session['pessoa_email'] = pessoa.email # Adiciona o email à sessão

        # redireciona para a view 'lobby' (ajuste o name se necessário)
        return redirect(reverse('lobby'))

    return render(request, 'login.html')

def lobby(request):
    historias = Historia.objects.all()
    pessoas = Pessoa.objects.all()
    return render(request, 'lobby.html', {'historias': historias, 'pessoas': pessoas})
    
def publicar(request): 
    if request.method == 'POST':
        titulo = request.POST.get('titulo')
        conteudo = request.POST.get('conteudo')
        sinopse = request.POST.get('sinopse', '')
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        hnome = request.POST.get('hnome')

        try:
            pessoa = Pessoa.objects.get(nome=nome, email=email)
        except Pessoa.DoesNotExist:
            return render(request, 'publicar.html', {'error': 'Pessoa não encontrada. Cadastre-se primeiro.'})

        nova_historia = Historia(titulo=titulo, conteudo=conteudo, sinopse=sinopse, hnome=Pessoa(nome=nome).nome) 
        nova_historia.save()

        if pessoa.hid:
            pessoa.hid += f',{nova_historia.id}'
        else: 
            pessoa.hid = str(nova_historia.id)
        pessoa.save()

        return redirect(reverse('lobby'))

    else: # Se o método for GET, preenche os campos com os dados da sessão
        logged_in_nome = request.session.get('pessoa_nome', '')
        logged_in_email = request.session.get('pessoa_email', '')
        context = {
            'nome': logged_in_nome, 
            'email': logged_in_email,
            'titulo': '',
            'conteudo': '',
            'sinopse': ''
        }
        return render(request, 'publicar.html', context)
    
def leitura(request):
    historias = Historia.objects.all() ,
    pessoa = Pessoa.objects.get(id=request.session.get('pessoa_nome'))
    return render(request, 'leitura.html', {'historias': historias, 'pessoa': pessoa} ) 

def crud_view(request):
    pessoas = Pessoa.objects.all()
    historias = Historia.objects.all()
    return render(request, 'index.html', {'pessoas': pessoas, 'historias': historias})

def delete_pessoa(request, pk):
    pessoa = get_object_or_404(Pessoa, pk=pk)
    pessoa.delete()
    return redirect('crud')

def delete_historia(request, pk):
    historia = get_object_or_404(Historia, pk=pk)
    historia.delete()
    return redirect('crud')

def secret_login(request):
    if request.method == 'POST':
        password = request.POST.get('password')
        if password == 'admin':
            return redirect(reverse('crud'))
    return redirect(reverse('login'))